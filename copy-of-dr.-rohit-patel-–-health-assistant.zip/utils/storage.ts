
import { PrescriptionData, PatientData } from '../types';
import { getCurrentUser } from './auth';

const BASE_STORAGE_KEY = 'dr_rohit_patel_prescriptions';
const BASE_DRAFT_KEY = 'dr_rohit_patel_draft_form';

// Helper to get user-specific storage key to ensure data isolation
const getStorageKey = () => {
    const user = getCurrentUser();
    // Use email as key identifier
    return user ? `${BASE_STORAGE_KEY}_${user.email}` : BASE_STORAGE_KEY;
};

const getDraftKey = () => {
    const user = getCurrentUser();
    // Use email as key identifier
    return user ? `${BASE_DRAFT_KEY}_${user.email}` : BASE_DRAFT_KEY;
};

export const savePrescriptionToHistory = (data: PrescriptionData): void => {
  try {
    const existing = getHistory();
    // Prepend new prescription
    const updated = [data, ...existing];
    localStorage.setItem(getStorageKey(), JSON.stringify(updated));
  } catch (error) {
    console.error("Failed to save to history", error);
  }
};

export const getHistory = (): PrescriptionData[] => {
  try {
    const data = localStorage.getItem(getStorageKey());
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Failed to load history", error);
    return [];
  }
};

export const updateFeedbackInHistory = (id: string, feedback: { rating: number; comment: string }): void => {
  try {
    const existing = getHistory();
    const updated = existing.map(item => 
      item.id === id ? { ...item, feedback } : item
    );
    localStorage.setItem(getStorageKey(), JSON.stringify(updated));
  } catch (error) {
    console.error("Failed to update feedback", error);
  }
};

// Draft Auto-Save Functions

export const saveDraft = (data: PatientData): void => {
  try {
    // We create a copy and destructure to remove reports (images)
    // Saving base64 images to localStorage will quickly exceed the 5MB quota.
    const { reports, ...textData } = data;
    localStorage.setItem(getDraftKey(), JSON.stringify(textData));
  } catch (error) {
    console.warn("Failed to save form draft", error);
  }
};

export const loadDraft = (): Partial<PatientData> | null => {
  try {
    const data = localStorage.getItem(getDraftKey());
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.warn("Failed to load form draft", error);
    return null;
  }
};

export const clearDraft = (): void => {
  try {
    localStorage.removeItem(getDraftKey());
  } catch (error) {
    console.error("Failed to clear draft", error);
  }
};
