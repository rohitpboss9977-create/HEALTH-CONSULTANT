
import { PrescriptionData } from '../types';

export const encodePrescriptionForUrl = (data: PrescriptionData): string => {
  try {
    const json = JSON.stringify(data);
    // encodeURIComponent handles Unicode characters (like Hindi) before base64 encoding
    return btoa(encodeURIComponent(json));
  } catch (error) {
    console.error("Failed to encode prescription", error);
    return "";
  }
};

export const decodePrescriptionFromUrl = (encoded: string): PrescriptionData | null => {
  try {
    // Decode base64 then decode URI component to get original JSON string
    const json = decodeURIComponent(atob(encoded));
    return JSON.parse(json);
  } catch (error) {
    console.error("Failed to decode prescription from URL", error);
    return null;
  }
};
