
import { User } from '../types';

const USERS_KEY = 'dr_rohit_patel_users';
const SESSION_KEY = 'dr_rohit_patel_session';
const OTP_STORAGE_KEY = 'dr_rohit_patel_temp_otp';

// --- OTP LOGIC ---

export const sendOTP = (email: string): string => {
  // Generate a random 4-digit OTP
  const otp = Math.floor(1000 + Math.random() * 9000).toString();
  
  // Store valid OTP for this email in session storage (short-lived)
  sessionStorage.setItem(`${OTP_STORAGE_KEY}_${email}`, otp);
  
  // In a real app, this would trigger an Email API. 
  // Here we return it to be alerted to the user.
  return otp;
};

export const verifyOTP = (email: string, otp: string): boolean => {
  const storedOTP = sessionStorage.getItem(`${OTP_STORAGE_KEY}_${email}`);
  if (storedOTP && storedOTP === otp) {
    // Clear OTP after successful use to prevent replay
    sessionStorage.removeItem(`${OTP_STORAGE_KEY}_${email}`);
    return true;
  }
  return false;
};

// --- USER MANAGEMENT ---

export const checkUserExists = (email: string): boolean => {
  const usersStr = localStorage.getItem(USERS_KEY);
  const users: User[] = usersStr ? JSON.parse(usersStr) : [];
  return !!users.find(u => u.email === email);
};

export const registerAndLogin = (user: User): { success: boolean; message: string } => {
  try {
    const usersStr = localStorage.getItem(USERS_KEY);
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];

    // Add or Update user
    const existingIndex = users.findIndex(u => u.email === user.email);
    if (existingIndex >= 0) {
        users[existingIndex] = user; // Update name if changed
    } else {
        users.push(user);
    }
    
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    
    // Set Session
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    
    return { success: true, message: 'Login successful.' };
  } catch (error) {
    return { success: false, message: 'Storage error.' };
  }
};

export const loginExistingUser = (email: string): { success: boolean; user?: User } => {
    const usersStr = localStorage.getItem(USERS_KEY);
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];
    const user = users.find(u => u.email === email);
    
    if (user) {
        localStorage.setItem(SESSION_KEY, JSON.stringify(user));
        return { success: true, user };
    }
    return { success: false };
}

export const logoutUser = (): void => {
  localStorage.removeItem(SESSION_KEY);
};

export const getCurrentUser = (): User | null => {
  const sessionStr = localStorage.getItem(SESSION_KEY);
  return sessionStr ? JSON.parse(sessionStr) : null;
};
