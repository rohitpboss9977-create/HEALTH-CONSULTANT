

import { GoogleGenAI, Type, Schema } from "@google/genai";
import { PatientData, PrescriptionData } from "../types";
import { SYSTEM_INSTRUCTION } from "../constants";

const apiKey = process.env.API_KEY;

// Define the response schema for structured JSON output
const prescriptionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    patientSummary: {
      type: Type.STRING,
      description: "A summary of the patient's details and main complaints.",
    },
    possibleDiagnosis: {
      type: Type.STRING,
      description: "A clinical diagnosis (e.g. Acute Pharyngitis, Viral Pyrexia).",
    },
    medicines: {
      type: Type.ARRAY,
      description: "List of medicines covering Antibiotics, Steroids, Painkillers, etc.",
      items: {
        type: Type.OBJECT,
        properties: {
          category: {
            type: Type.STRING,
            enum: ['Antibiotic', 'Pain/Fever', 'Gas/Acidity', 'Nutrient', 'Steroid', 'Other'],
            description: "Category of the medicine",
          },
          name: {
            type: Type.STRING,
            description: "Standard Indian Brand Name + Generic (e.g. Tab. Dolo 650 (Paracetamol))",
          },
          alternatives: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "1-2 alternative brand names.",
          },
          dosage: {
            type: Type.STRING,
            description: "Dosage (e.g., 1 Tab BD x 3 days)",
          },
          instruction: {
            type: Type.STRING,
            description: "Specific instruction (e.g., After food)",
          },
          isPrescriptionRequired: {
            type: Type.BOOLEAN,
            description: "True if it is an antibiotic, steroid or strong drug.",
          },
        },
        required: ["category", "name", "dosage", "instruction", "isPrescriptionRequired"],
      },
    },
    recommendedTests: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of relevant lab investigations (Microbiology/Pathology).",
    },
    homeCareInstructions: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Strict clinical advice.",
    },
    lifestyleDietAdvice: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Specific diet restrictions.",
    },
    visitDoctorFlags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Red flags requiring immediate hospitalization.",
    },
    disclaimer: {
      type: Type.STRING,
      description: "The mandatory safety disclaimer.",
    },
  },
  required: [
    "patientSummary",
    "possibleDiagnosis",
    "medicines",
    "recommendedTests",
    "homeCareInstructions",
    "lifestyleDietAdvice",
    "visitDoctorFlags",
    "disclaimer",
  ],
};

export const generatePrescription = async (
  data: PatientData
): Promise<PrescriptionData> => {
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey });

  const textPrompt = `
    **ROLE:** You are a Senior Specialist following specific medical manuals.
    
    **REFERENCE BOOKS TO APPLY:**
    1. **GP Protocols (Practical Dosing):** **"General Practice" by Ghanashyam Vaidya**. Use his practical, symptom-oriented approach for common ailments.
    2. **Pharmacology (Safety & Choice):** **"Essentials of Medical Pharmacology" by KD Tripathi** AND **"Pharmacology for Medical Graduates" by Tara Shanbhag**. Use KDT for deep safety/mechanism and Shanbhag for concise indications.
    3. **Infections (Antibiotic Choice):** **"Essentials of Medical Microbiology" by Apurba Sastry**. Use the Syndromic Approach to decide IF antibiotic is needed and WHICH one covers the likely organism.
    4. **History & Examination:** **"Hutchison's Clinical Methods"** AND **Archith Boloor**.
    5. **Pathology:** **Harsh Mohan** (Mechanism) AND **Ramadas Nayak** (Criteria).
    6. **Surgery:** **S. Das** (Clinical Surgery).
    7. **Pediatrics:** **Parul Datta** (Weight-based dosing).
    8. **Mental Health:** **R. Sreevani**.
    9. **Internal Medicine (Gold Standard):** **"Harrison's Principles of Internal Medicine"**. Use for pathophysiology and standard treatment protocols.
    10. **Clinical Medicine (Comprehensive):** **"Kumar & Clark's Clinical Medicine"**. Use for holistic disease management and clear clinical feature correlation.
    11. **Cardiology (Congenital):** **"Percutaneous Interventions for Congenital Heart Disease" by Sievert et al.**. Use for identifying congenital heart signs and referral logic.
    12. **Holistic Harmony:** **"Harmony in Healing" by James Garber**. Use for constitutional lifestyle advice and restoring physiological balance in the Diet section.
    13. **Medical Ethics:** **"Medical Ethics in Clinical Practice" by Matjaž Zwitter**. Ensure advice respects Autonomy, Beneficence, and Non-maleficence with a compassionate tone.
    
    **PATIENT DETAILS:**
    Language Preference: ${data.language} (Output non-medical text in this language)
    Name: ${data.name}
    Age: ${data.age}
    Gender: ${data.gender}
    Weight: ${data.weight ? data.weight + " kg" : "Not specified"}
    Symptoms: ${data.symptoms}
    Known Disease: ${data.knownDisease || "None"}
    Duration: ${data.duration}
    Additional Notes: ${data.additionalNotes || "None"}

    ${data.reports && data.reports.length > 0 ? "IMPORTANT: The patient has uploaded photos of the AFFECTED AREA or medical reports. Carefully analyze the visuals to determine the condition and prescribe accordingly." : ""}

    **TASK:**
    Generate a **Precise & Expert Clinical Prescription**.
    
    **LOGIC:**
    1. **Analysis:** Use **Hutchison's** and **Boloor** to interpret symptoms.
    2. **Diagnosis:** Use **Harrison's** / **Kumar & Clark** / **Harsh Mohan** / **Nayak** to identify the condition.
    3. **Microbiology:** If prescribing an Antibiotic, ensure it aligns with **Apurba Sastry's** guidelines for the likely organism. (e.g. Don't give strong antibiotics for simple viral cold).
    4. **Pharmacology:** Check **KD Tripathi** & **Tara Shanbhag** for best drug class, safety, and indications.
    5. **Treatment:** Use **Ghanashyam Vaidya's** practical combinations (e.g., Antacid + Analgesic + Antibiotic if needed).
    6. **Ethics & Compassion:** Apply **Matjaž Zwitter's** principles. Explain *why* (Autonomy) and ensure tone is empathetic.
    7. **Dosing:** Clear, patient-friendly instructions (1-0-1).
    8. **Brands:** High-quality Indian Ethical Brands.
    9. **Safety:** Always include PPIs with NSAIDs. 
    10. **Lifestyle:** Use **James Garber's** principles to suggest balance-restoring lifestyle habits.

    If Language is Hindi, translate advice/instructions but keep Drug Names in English.
  `;

  // Prepare contents with optional images
  const parts: any[] = [{ text: textPrompt }];
  
  if (data.reports) {
    data.reports.forEach(report => {
      parts.push({
        inlineData: {
          mimeType: report.mimeType,
          data: report.data
        }
      });
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: prescriptionSchema,
        temperature: 0.3, 
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from AI.");
    }

    const parsed = JSON.parse(text) as PrescriptionData;
    // Add metadata locally
    parsed.timestamp = Date.now();
    parsed.id = crypto.randomUUID();
    parsed.patientName = data.name;
    parsed.age = data.age;
    parsed.gender = data.gender;
    parsed.weight = data.weight;

    return parsed;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
