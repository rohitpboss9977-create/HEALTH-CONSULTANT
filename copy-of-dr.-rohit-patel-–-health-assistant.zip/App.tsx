
import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import PatientForm from './components/PatientForm';
import PrescriptionCard from './components/PrescriptionCard';
import HistoryView from './components/HistoryView';
import { generatePrescription } from './services/geminiService';
import { PatientData, PrescriptionData } from './types';
import { savePrescriptionToHistory, getHistory, clearDraft } from './utils/storage';
import { decodePrescriptionFromUrl } from './utils/sharing';
import { AlertCircle } from 'lucide-react';

type ViewMode = 'CONSULTATION' | 'HISTORY';

const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('CONSULTATION');
  const [prescription, setPrescription] = useState<PrescriptionData | null>(null);
  const [isSharedView, setIsSharedView] = useState<boolean>(false);
  const [isHistoryItemView, setIsHistoryItemView] = useState<boolean>(false);
  
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // State to track history list
  const [historyList, setHistoryList] = useState<PrescriptionData[]>([]);

  // Ref for auto-scrolling to result
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // 1. Check for Shared Link (Preview Mode)
    const params = new URLSearchParams(window.location.search);
    const sharedRx = params.get('rx');

    if (sharedRx) {
      const decoded = decodePrescriptionFromUrl(sharedRx);
      if (decoded) {
        setPrescription(decoded);
        setIsSharedView(true);
      } else {
        setError("Invalid or expired shared link.");
        setIsSharedView(false);
      }
    } else {
      // Default to Doctor View (Open Access)
      setIsSharedView(false);
    }

    // 2. Load history on mount
    setHistoryList(getHistory());
  }, []);

  const refreshHistory = () => {
    setHistoryList(getHistory());
  };

  const handleFormSubmit = async (data: PatientData) => {
    setLoading(true);
    setError(null);
    try {
      const result = await generatePrescription(data);
      setPrescription(result);
      setIsHistoryItemView(false);
      
      // Auto save to history
      savePrescriptionToHistory(result);
      refreshHistory();
      
      // Clear the form draft upon success
      clearDraft();
      
      // Scroll to result after a short delay to allow render
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);

    } catch (err: any) {
      setError(err.message || "Failed to generate guidelines. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    if (isSharedView) return; 
    
    // In Doctor view, reset just clears the result card so they can use the form again
    setPrescription(null);
    setIsHistoryItemView(false);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleHistory = () => {
    if (isSharedView) return; 

    if (viewMode === 'HISTORY') {
      setViewMode('CONSULTATION');
      // If we had a history item open, clear it so we go back to the form state
      if (isHistoryItemView) {
        setPrescription(null);
        setIsHistoryItemView(false);
      }
      return;
    }
    
    refreshHistory();
    setViewMode('HISTORY');
  };

  const handleSelectHistoryItem = (item: PrescriptionData) => {
    setPrescription(item);
    setIsHistoryItemView(true); // Marks this as viewing a historical item (hides form)
    setViewMode('CONSULTATION');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // -------------------------------------------------------------------------
  // MAIN APP RENDER
  // -------------------------------------------------------------------------
  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-900 pb-12 print:bg-white print:pb-0">
      {/* Header: Hidden in Shared View */}
      {!isSharedView && (
        <Header 
          onHistoryClick={toggleHistory} 
          showHistoryBtn={true} 
        />
      )}

      <main className="max-w-4xl mx-auto px-4 py-8 print:max-w-none print:px-0 print:py-0 print:mx-0">
        
        {/* Shared View Banner */}
        {isSharedView && (
          <div className="mb-6 bg-teal-50 border border-teal-200 p-4 rounded-lg shadow-sm text-center animate-fade-in-up">
            <p className="text-teal-800 font-medium text-sm">You are viewing a shared health guideline (Read Only)</p>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-r shadow-sm flex items-start gap-3">
            <AlertCircle className="text-red-500 w-6 h-6 flex-shrink-0" />
            <div>
              <h3 className="text-red-800 font-bold">Error</h3>
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          </div>
        )}

        {/* --- VIEW LOGIC --- */}
        
        {/* 1. SHARED VIEW (Patient Link) - PREVIEW ONLY */}
        {isSharedView ? (
           prescription ? (
             <PrescriptionCard 
               data={prescription} 
               onReset={() => {}} 
               isSharedView={true} 
             />
           ) : (
             <div className="text-center py-20">
               <div className="animate-spin w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full mx-auto mb-4"></div>
               <p className="text-gray-500">Loading prescription...</p>
             </div>
           )
        ) : (
           // 2. DOCTOR VIEW
           <>
             {/* HISTORY LIST VIEW */}
             {viewMode === 'HISTORY' && (
                <HistoryView 
                  history={historyList} 
                  onSelect={handleSelectHistoryItem} 
                  onBack={() => setViewMode('CONSULTATION')} 
                />
             )}

             {/* CONSULTATION VIEW (Form + Result) */}
             {viewMode === 'CONSULTATION' && (
                <>
                   {/* SHOW FORM: If NOT viewing a history item */}
                   {!isHistoryItemView && (
                      <PatientForm onSubmit={handleFormSubmit} isLoading={loading} />
                   )}

                   {/* SHOW RESULT: If prescription exists (Either generated or history item) */}
                   {prescription && (
                      <div ref={resultRef} className={`${!isHistoryItemView ? 'mt-12 pt-12 border-t border-gray-200' : ''}`}>
                         {!isHistoryItemView && (
                           <div className="text-center mb-8">
                             <h2 className="text-2xl font-serif font-bold text-teal-800">Clinical Prescription Generated</h2>
                             <p className="text-gray-500 text-sm">Review the details below</p>
                           </div>
                         )}
                         <PrescriptionCard 
                           data={prescription} 
                           onReset={handleReset} 
                           isHistoryView={isHistoryItemView}
                           isSharedView={false}
                         />
                      </div>
                   )}
                </>
             )}
           </>
        )}

      </main>
      
      {/* Footer */}
      {!isSharedView && (
        <footer className="text-center text-gray-400 text-sm py-6 print:hidden">
          <p>&copy; {new Date().getFullYear()} Dr. Rohit Patel AI Health Assistant. All rights reserved.</p>
          <p className="text-xs mt-1">Powered by Google Gemini 2.5</p>
        </footer>
      )}
    </div>
  );
};

export default App;
