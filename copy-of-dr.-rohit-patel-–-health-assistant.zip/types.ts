
export interface PatientData {
  name: string;
  age: string; // kept as string for input flexibility, parsed later if needed
  gender: string;
  weight?: string;
  language: 'English' | 'Hindi';
  symptoms: string;
  knownDisease?: string;
  duration: string;
  additionalNotes?: string;
  reports?: {
    mimeType: string;
    data: string; // base64
  }[];
}

export interface Medicine {
  category: 'Antibiotic' | 'Pain/Fever' | 'Gas/Acidity' | 'Nutrient' | 'Steroid' | 'Other';
  name: string;
  dosage: string;
  instruction: string;
  isPrescriptionRequired: boolean;
  alternatives?: string[];
}

export interface PrescriptionData {
  id?: string; // Unique ID for storage
  timestamp?: number; // Date of generation
  patientName?: string; // Store name for history view
  age?: string;
  gender?: string;
  weight?: string;
  patientSummary: string;
  possibleDiagnosis: string;
  medicines: Medicine[];
  recommendedTests: string[];
  homeCareInstructions: string[];
  lifestyleDietAdvice: string[];
  visitDoctorFlags: string[];
  disclaimer: string;
  feedback?: {
    rating: number;
    comment: string;
  };
}

export interface User {
  email: string;
  name: string;
}

export enum Gender {
  Male = 'Male',
  Female = 'Female',
  Other = 'Other',
}
