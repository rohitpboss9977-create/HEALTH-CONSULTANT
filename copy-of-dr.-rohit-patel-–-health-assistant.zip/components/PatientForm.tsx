import React, { useState, useEffect } from 'react';
import { PatientData, Gender } from '../types';
import { saveDraft, loadDraft } from '../utils/storage';
import { Activity, User, Clock, AlertCircle, FileText, Scale, Upload, X, Languages } from 'lucide-react';

interface PatientFormProps {
  onSubmit: (data: PatientData) => void;
  isLoading: boolean;
}

const PatientForm: React.FC<PatientFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<PatientData>({
    name: '',
    age: '',
    gender: Gender.Male,
    weight: '',
    language: 'English',
    symptoms: '',
    knownDisease: '',
    duration: '',
    additionalNotes: '',
    reports: [],
  });

  // Load draft on mount
  useEffect(() => {
    const draft = loadDraft();
    if (draft) {
      setFormData(prev => ({
        ...prev,
        ...draft,
        reports: [] // Images are not restored from draft
      }));
    }
  }, []);

  // Auto-save draft on changes (Debounced)
  useEffect(() => {
    const handler = setTimeout(() => {
      // Only save if there is at least some data
      if (formData.name || formData.symptoms || formData.age) {
        saveDraft(formData);
      }
    }, 500);

    return () => clearTimeout(handler);
  }, [formData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      const processFiles = files.map(file => {
         return new Promise<{mimeType: string, data: string}>((resolve, reject) => {
             const reader = new FileReader();
             reader.onload = () => {
                 const result = reader.result as string;
                 // Remove data:image/png;base64, prefix
                 const base64 = result.split(',')[1];
                 resolve({
                     mimeType: file.type,
                     data: base64
                 });
             };
             reader.onerror = reject;
             reader.readAsDataURL(file);
         });
      });

      Promise.all(processFiles).then(results => {
          setFormData(prev => ({
              ...prev,
              reports: [...(prev.reports || []), ...results]
          }));
      });
    }
  };

  const removeReport = (index: number) => {
      setFormData(prev => ({
          ...prev,
          reports: prev.reports?.filter((_, i) => i !== index)
      }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100 animate-fade-in-up w-full max-w-5xl mx-auto">
      {/* Letterhead Style Header for Form */}
      <div className="bg-gradient-to-r from-teal-700 to-teal-800 px-6 py-6 border-b-4 border-teal-500 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 className="text-2xl font-serif font-bold text-white tracking-wide">Dr. Rohit Patel</h1>
                <p className="text-teal-100 text-xs font-bold uppercase tracking-widest mt-1">General Practitioner (AI)</p>
            </div>
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-white/20">
                <Languages className="w-4 h-4 text-teal-100" />
                <select
                    name="language"
                    value={formData.language}
                    onChange={handleChange}
                    className="text-sm bg-transparent text-white font-medium border-none outline-none focus:ring-0 cursor-pointer"
                >
                    <option value="English" className="text-gray-800">English</option>
                    <option value="Hindi" className="text-gray-800">Hindi (हिंदी)</option>
                </select>
            </div>
        </div>
      </div>
      
      <div className="bg-teal-50 px-6 py-3 border-b border-teal-100 flex items-center gap-2">
         <User className="w-4 h-4 text-teal-700" />
         <span className="text-xs font-bold text-teal-800 uppercase tracking-wide">Patient Registration Form</span>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-8 relative">
        {/* Watermark */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] z-0 overflow-hidden">
             <Activity className="w-[400px] h-[400px] text-teal-900" />
        </div>

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Demographics */}
          <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Patient Name</label>
                <input
                  required
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Full Name"
                  className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800 placeholder-gray-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Age</label>
                  <input
                    required
                    type="number"
                    name="age"
                    value={formData.age}
                    onChange={handleChange}
                    placeholder="Yrs"
                    className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Gender</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800"
                  >
                    <option value={Gender.Male}>Male</option>
                    <option value={Gender.Female}>Female</option>
                    <option value={Gender.Other}>Other</option>
                  </select>
                </div>
                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-wider block">Weight</label>
                    <div className="relative">
                        <input
                            type="number"
                            name="weight"
                            min="0"
                            value={formData.weight}
                            onChange={handleChange}
                            placeholder="Kg"
                            className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800"
                        />
                        <span className="absolute right-3 top-3.5 text-gray-400 text-xs font-bold pointer-events-none">KG</span>
                    </div>
                </div>
              </div>
              
               <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                   <Clock className="w-3 h-3" /> Duration of Illness
                </label>
                <input
                  required
                  type="text"
                  name="duration"
                  value={formData.duration}
                  onChange={handleChange}
                  placeholder="e.g. 2 days, since last night"
                  className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800"
                />
              </div>
          </div>

          {/* Right Column: Clinical Data */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-3 h-3 text-teal-600" />
                  Chief Complaints / Symptoms
                </div>
              </label>
              <textarea
                required
                name="symptoms"
                value={formData.symptoms}
                onChange={handleChange}
                placeholder="Describe symptoms in detail..."
                rows={4}
                className="w-full px-4 py-3 bg-white rounded-lg border-2 border-teal-100 focus:border-teal-500 focus:ring-0 transition-colors font-medium text-gray-800 resize-none"
              />
            </div>

            <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                <AlertCircle className="w-3 h-3 text-teal-600" />
                History / Known Conditions
                </label>
                <input
                type="text"
                name="knownDisease"
                value={formData.knownDisease}
                onChange={handleChange}
                placeholder="e.g. Diabetes, Hypertension (Optional)"
                className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800"
                />
            </div>
            
             <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                    <FileText className="w-3 h-3 text-teal-600" />
                    Additional Notes
                </label>
                <input
                    type="text"
                    name="additionalNotes"
                    value={formData.additionalNotes}
                    onChange={handleChange}
                    placeholder="Allergies, previous meds..."
                    className="w-full px-4 py-3 bg-gray-50 rounded-lg border border-gray-200 focus:bg-white focus:ring-2 focus:ring-teal-500 focus:border-teal-500 transition-all font-medium text-gray-800"
                />
            </div>
          </div>
        </div>

        {/* File Upload */}
        <div className="relative z-10 pt-4 border-t border-dashed border-gray-200">
             <label className="text-xs font-bold text-gray-500 uppercase tracking-wider flex items-center gap-2 mb-3">
                <Upload className="w-3 h-3 text-teal-600" />
                Attachments (Reports / Photos)
             </label>
             <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                 <div className="md:col-span-1 border-2 border-dashed border-teal-200 rounded-xl bg-teal-50/50 hover:bg-teal-50 transition-colors cursor-pointer relative flex flex-col items-center justify-center p-4 text-center h-28">
                    <input 
                        type="file" 
                        accept="image/*" 
                        multiple 
                        onChange={handleFileChange}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className="bg-white p-2 rounded-full shadow-sm mb-2">
                        <Upload className="w-4 h-4 text-teal-600" />
                    </div>
                    <span className="text-xs font-bold text-teal-700">Add File</span>
                 </div>
                 
                 {/* Preview Images */}
                 <div className="md:col-span-3 flex gap-3 overflow-x-auto pb-2 custom-scrollbar">
                     {formData.reports && formData.reports.length > 0 ? (
                         formData.reports.map((report, idx) => (
                             <div key={idx} className="relative w-28 h-28 flex-shrink-0 border border-gray-200 rounded-xl overflow-hidden shadow-sm group">
                                 <img 
                                    src={`data:${report.mimeType};base64,${report.data}`} 
                                    alt="report" 
                                    className="w-full h-full object-cover"
                                 />
                                 <button 
                                    type="button"
                                    onClick={() => removeReport(idx)}
                                    className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                 >
                                     <X className="w-3 h-3" />
                                 </button>
                             </div>
                         ))
                     ) : (
                         <div className="flex items-center text-gray-400 text-sm italic pl-2">
                             No files selected
                         </div>
                     )}
                 </div>
             </div>
        </div>

        <div className="pt-6 border-t border-gray-100">
            <button
            type="submit"
            disabled={isLoading}
            className={`w-full flex items-center justify-center py-4 rounded-xl text-white font-serif font-bold text-lg shadow-xl transform transition-all 
                ${isLoading 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-gradient-to-r from-teal-600 to-teal-800 hover:from-teal-700 hover:to-teal-900 hover:scale-[1.01] hover:shadow-2xl'}`}
            >
            {isLoading ? (
                <span className="flex items-center gap-3">
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing Diagnosis...
                </span>
            ) : (
                'Generate Clinical Prescription'
            )}
            </button>
        </div>
      </form>
    </div>
  );
};

export default PatientForm;