
import React, { useState, useEffect } from 'react';
import { sendOTP, verifyOTP, checkUserExists, registerAndLogin, loginExistingUser } from '../utils/auth';
import { Mail, ArrowRight, ShieldCheck, KeyRound, User as UserIcon, CheckCircle, RefreshCw, Lock } from 'lucide-react';

interface AuthFormProps {
  onLoginSuccess: () => void;
}

type AuthStep = 'EMAIL' | 'OTP' | 'NAME';

const AuthForm: React.FC<AuthFormProps> = ({ onLoginSuccess }) => {
  const [step, setStep] = useState<AuthStep>('EMAIL');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  
  // Captcha State
  const [captchaCode, setCaptchaCode] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Generate Captcha on mount
  useEffect(() => {
    generateCaptcha();
  }, []);

  // Focus management and error clearing
  useEffect(() => {
     setError('');
  }, [step]);

  const generateCaptcha = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Exclude I, 1, O, 0 for clarity
    let result = '';
    for (let i = 0; i < 5; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptchaCode(result);
    setCaptchaInput(''); // Reset input
  };

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !email.includes('@')) {
        setError("Please enter a valid email address.");
        return;
    }

    if (captchaInput.toUpperCase() !== captchaCode) {
        setError("Incorrect CAPTCHA. Please try again.");
        generateCaptcha(); // Refresh captcha on failure to prevent brute force
        return;
    }
    
    setIsLoading(true);
    // Simulate network delay
    setTimeout(() => {
        const code = sendOTP(email);
        setIsLoading(false);
        setStep('OTP');
        // Simulate Email delivery
        alert(`OTP sent to ${email}: ${code}`);
    }, 800);
  };

  const handleVerifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 4) {
        setError("Please enter the 4-digit OTP.");
        return;
    }

    const isValid = verifyOTP(email, otp);
    if (isValid) {
        // Check if user exists
        const exists = checkUserExists(email);
        if (exists) {
            // Login immediately
            loginExistingUser(email);
            onLoginSuccess();
        } else {
            // New user, ask for name
            setStep('NAME');
        }
    } else {
        setError("Invalid OTP. Please try again.");
    }
  };

  const handleCompleteRegistration = (e: React.FormEvent) => {
      e.preventDefault();
      if (!name.trim()) {
          setError("Please enter your name.");
          return;
      }

      registerAndLogin({ email, name });
      onLoginSuccess();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up">
        {/* Header */}
        <div className="bg-teal-700 p-8 text-center relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-full bg-teal-600 opacity-50 transform rotate-12 scale-150 origin-bottom-right"></div>
           <div className="relative z-10">
               <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
                 <ShieldCheck className="w-8 h-8 text-white" />
               </div>
               <h2 className="text-2xl font-bold text-white font-serif tracking-wide">Dr. Rohit Patel</h2>
               <p className="text-teal-100 text-sm mt-1">Secure Health Assistant Portal</p>
           </div>
        </div>

        {/* Form Container */}
        <div className="p-8">
            <div className="mb-6 text-center">
                <h3 className="text-xl font-bold text-gray-800">
                    {step === 'EMAIL' && "Welcome Back"}
                    {step === 'OTP' && "Verify Identity"}
                    {step === 'NAME' && "Profile Details"}
                </h3>
                <p className="text-gray-500 text-sm mt-1">
                    {step === 'EMAIL' && "Enter your email to get started"}
                    {step === 'OTP' && `Enter the OTP sent to ${email}`}
                    {step === 'NAME' && "Please tell us your name"}
                </p>
            </div>

            {error && (
                <div className="mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg flex items-center gap-2 border border-red-100 animate-pulse">
                    <CheckCircle className="w-4 h-4 text-red-500" /> {error}
                </div>
            )}

            {/* STEP 1: EMAIL & CAPTCHA */}
            {step === 'EMAIL' && (
                <form onSubmit={handleSendOTP} className="space-y-5">
                    <div className="relative">
                        <Mail className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                        <input 
                            type="email" 
                            placeholder="Email Address"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                            autoFocus
                        />
                    </div>

                    {/* CAPTCHA SECTION */}
                    <div className="flex gap-3">
                        <div className="relative flex-1">
                            <Lock className="absolute left-3 top-3.5 w-4 h-4 text-gray-400" />
                            <input 
                                type="text" 
                                placeholder="Enter Captcha"
                                value={captchaInput}
                                onChange={(e) => setCaptchaInput(e.target.value)}
                                className="w-full pl-9 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all uppercase"
                            />
                        </div>
                        <div className="flex items-center gap-2 bg-gray-100 border border-gray-200 rounded-lg px-3 py-2 select-none">
                            <span 
                                className="text-xl font-bold text-gray-600 tracking-widest font-mono line-through decoration-gray-400/50"
                                style={{ 
                                    textShadow: '1px 1px 2px rgba(0,0,0,0.1)',
                                    transform: 'skew(-5deg)'
                                }}
                            >
                                {captchaCode}
                            </span>
                            <button 
                                type="button" 
                                onClick={generateCaptcha}
                                className="text-gray-400 hover:text-teal-600 transition-colors p-1"
                                title="Refresh Captcha"
                            >
                                <RefreshCw className="w-4 h-4" />
                            </button>
                        </div>
                    </div>

                    <button 
                        type="submit" 
                        disabled={isLoading}
                        className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3.5 rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                    >
                        {isLoading ? 'Sending OTP...' : 'Get OTP'} <ArrowRight className="w-4 h-4" />
                    </button>
                </form>
            )}

            {/* STEP 2: OTP */}
            {step === 'OTP' && (
                <form onSubmit={handleVerifyOTP} className="space-y-5">
                    <div className="relative">
                        <KeyRound className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                        <input 
                            type="number" 
                            placeholder="Enter 4-digit OTP"
                            value={otp}
                            onChange={(e) => setOtp(e.target.value.slice(0, 4))}
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all tracking-widest text-center text-lg font-bold"
                            autoFocus
                        />
                    </div>
                    <button 
                        type="submit" 
                        className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3.5 rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                    >
                        Verify & Login
                    </button>
                    <button 
                        type="button"
                        onClick={() => { setStep('EMAIL'); setOtp(''); }}
                        className="w-full text-sm text-gray-500 hover:text-teal-600 py-2"
                    >
                        Change Email Address
                    </button>
                </form>
            )}

            {/* STEP 3: NAME (New Users) */}
            {step === 'NAME' && (
                <form onSubmit={handleCompleteRegistration} className="space-y-5">
                    <div className="relative">
                        <UserIcon className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                        <input 
                            type="text" 
                            placeholder="Enter Full Name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition-all"
                            autoFocus
                        />
                    </div>
                    <button 
                        type="submit" 
                        className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-3.5 rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                    >
                        Complete Registration
                    </button>
                </form>
            )}

        </div>
        
        <div className="bg-gray-50 py-3 text-center border-t border-gray-100">
             <p className="text-xs text-gray-400 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Secure Email Authentication
             </p>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;
