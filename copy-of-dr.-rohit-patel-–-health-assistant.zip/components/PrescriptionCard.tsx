
import React, { useState } from 'react';
import { PrescriptionData } from '../types';
import { updateFeedbackInHistory } from '../utils/storage';
import { encodePrescriptionForUrl } from '../utils/sharing';
import { Pill, Utensils, AlertTriangle, FileSearch, Stethoscope, HeartPulse, RefreshCw, AlertCircle, ShieldCheck, Zap, Star, MessageSquare, CheckCircle, Lock, Share2, Mail, MessageCircle, Download, Syringe, Save, Hash, Phone, MapPin, Link, Eye } from 'lucide-react';

interface PrescriptionCardProps {
  data: PrescriptionData;
  onReset: () => void;
  isHistoryView?: boolean;
  isSharedView?: boolean;
}

const PrescriptionCard: React.FC<PrescriptionCardProps> = ({ data, onReset, isHistoryView = false, isSharedView = false }) => {
  const [feedback, setFeedback] = useState(data.feedback || { rating: 0, comment: '' });
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(!!data.feedback);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleFeedbackSubmit = () => {
      if (data.id && feedback.rating > 0) {
          updateFeedbackInHistory(data.id, feedback);
          setFeedbackSubmitted(true);
      }
  };

  const generateShareText = () => {
    return [
      `*Dr. Rohit Patel – AI Health Assistant*`,
      `--------------------------------`,
      `*Ref:* ${data.id?.slice(0, 8) || 'N/A'}`,
      `*Patient:* ${data.patientName || 'Patient'}`,
      `*Age/Sex:* ${data.age || 'N/A'} / ${data.gender || 'N/A'}`,
      `*Diagnosis:* ${data.possibleDiagnosis}`,
      ``,
      `*Rx Protocol:*`,
      ...data.medicines.map(m => `• ${m.name} (${m.dosage})`),
      ``,
      `*Clinical Advice:*`,
      ...data.homeCareInstructions.slice(0, 4).map(i => `• ${i}`),
      ``,
      `*Disclaimer:* ${data.disclaimer}`,
    ].join('\n');
  };

  const handleShare = (type: 'whatsapp' | 'email' | 'copy-link') => {
      const text = generateShareText();
      
      if (type === 'whatsapp') {
          window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
      } else if (type === 'email') {
          const subject = `Health Guideline - ${data.patientName || 'Patient'}`;
          window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
      } else if (type === 'copy-link') {
          const encoded = encodePrescriptionForUrl(data);
          const url = `${window.location.origin}${window.location.pathname}?rx=${encoded}`;
          navigator.clipboard.writeText(url).then(() => {
              alert("Link copied to clipboard!");
          });
      }
      setShowShareMenu(false);
  };

  const handleDownloadPdf = () => {
      setShowShareMenu(false);
      setIsDownloading(true);

      const element = document.getElementById('prescription-content');
      // Use the patient name for filename, sanitize it
      const safeName = (data.patientName || 'Patient').replace(/[^a-z0-9]/gi, '_');
      const fileName = `Prescription_${safeName}_${new Date().toISOString().split('T')[0]}.pdf`;

      const opt = {
        margin: [0.3, 0.25, 0.5, 0.25], // Top, Left, Bottom, Right (in inches)
        filename: fileName,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
            scale: 2, 
            useCORS: true,
            scrollY: 0,
            // 816px is 8.5 inches at 96 DPI (Letter width). 
            // Setting this ensures 1:1 scale for text size on PDF even if mobile screen is small.
            windowWidth: 816, 
        },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
        pagebreak: { mode: ['css', 'legacy'] } 
      };

      // @ts-ignore
      if (window.html2pdf) {
        // @ts-ignore
        const worker = window.html2pdf().set(opt).from(element);
        
        worker.toPdf().get('pdf').then((pdf: any) => {
            const totalPages = pdf.internal.getNumberOfPages();
            const pageWidth = pdf.internal.pageSize.getWidth(); // in inches
            const pageHeight = pdf.internal.pageSize.getHeight(); // in inches

            for (let i = 1; i <= totalPages; i++) {
                pdf.setPage(i);
                pdf.setFontSize(8);
                pdf.setTextColor(100, 116, 139); // Slate-500

                // Draw Divider Line (at bottom)
                const lineY = pageHeight - 0.5;
                pdf.setDrawColor(203, 213, 225); // Slate-300
                pdf.line(0.25, lineY, pageWidth - 0.25, lineY);

                // Footer Text
                const textY = pageHeight - 0.35;
                
                // Left: Website
                pdf.text('www.drohitpatel.ai', 0.25, textY);
                
                // Right: Page Numbers
                const pageText = `Page ${i} of ${totalPages}`;
                pdf.text(pageText, pageWidth - 0.25, textY, { align: 'right' });
            }
            
            // Save the PDF
            pdf.save(fileName);
        }).then(() => {
            setIsDownloading(false);
        }).catch((err: any) => {
            console.error("PDF generation failed", err);
            setIsDownloading(false);
            alert("PDF download failed. Using browser print instead.");
            window.print();
        });
      } else {
        window.print();
        setIsDownloading(false);
      }
  };

  return (
    <div className="flex flex-col items-center w-full">
      {/* 
        Responsive Container: 
        On Mobile: Width is 100%, content flows naturally.
        On Desktop: Max width 800px to resemble a paper.
      */}
      <div className="w-full flex justify-center pb-8 p-0 sm:p-4">
        
        {/* Main Card */}
        <div 
            id="prescription-content" 
            className="bg-white shadow-none sm:shadow-2xl relative shrink-0 w-full max-w-3xl print:shadow-none print:w-full"
            style={{ minHeight: '100vh' }}
        >
          {/* Decorative Top Accent */}
          <div className="h-2 bg-gradient-to-r from-teal-600 to-cyan-500 w-full"></div>

          {/* History/Saved/Preview Badge */}
          <div className="absolute top-4 right-4 z-10 flex" data-html2canvas-ignore="true">
            {isSharedView ? (
                <div className="bg-blue-600 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md print:hidden opacity-90">
                    <Eye className="w-3 h-3" /> Preview Only
                </div>
            ) : isHistoryView ? (
                <div className="bg-gray-600 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md print:hidden opacity-80">
                    <Lock className="w-3 h-3" /> Archived
                </div>
            ) : (
                <div className="bg-teal-600 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-md print:hidden opacity-80">
                    <Save className="w-3 h-3" /> Saved
                </div>
            )}
          </div>

          {/* Modern Header - Responsive (Stack on mobile, Row on desktop) */}
          <div className="px-6 py-6 sm:px-8 sm:py-8 flex flex-col md:flex-row justify-between items-start md:items-center relative overflow-hidden gap-6">
             {/* Background Shape */}
             <div className="absolute top-0 left-0 w-[70%] h-full bg-teal-50 skew-x-12 -translate-x-16 z-0"></div>

             <div className="relative z-10 flex items-center gap-5">
                <div className="bg-teal-600 p-3 rounded-xl shadow-lg text-white">
                  <Stethoscope className="w-8 h-8 sm:w-10 sm:h-10" />
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 tracking-tight font-serif">Dr. Rohit Patel</h1>
                  <p className="text-teal-600 font-bold text-xs uppercase tracking-widest mt-1">General Practitioner (AI)</p>
                  
                  {/* Contact Info - Darkened for PDF Visibility */}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mt-3 text-xs font-bold text-teal-900/80">
                     <span className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" /> +91-79753-25533</span>
                     <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> Bhopal, MP</span>
                  </div>
                </div>
             </div>

             <div className="relative z-10 w-full md:w-auto text-right flex flex-row md:flex-col justify-between items-center md:items-end">
                <div className="text-4xl sm:text-5xl font-black text-teal-900/10 md:absolute md:-top-4 md:-right-4 font-serif">RX</div>
                <div className="bg-white border border-teal-100 shadow-sm px-4 py-2 rounded-lg text-center">
                    <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Date</p>
                    <p className="text-lg font-bold text-teal-800">
                      {data.timestamp ? new Date(data.timestamp).toLocaleDateString() : new Date().toLocaleDateString()}
                    </p>
                </div>
                <p className="text-[10px] text-gray-400 mt-2">REF: {data.id?.slice(0, 8).toUpperCase() || '---'}</p>
             </div>
          </div>

          {/* Patient Details Grid - Responsive */}
          <div className="px-4 sm:px-8 pb-6">
             <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-6 relative">
                 <div className="absolute top-0 left-6 -translate-y-1/2 bg-white px-2 text-xs font-bold text-slate-400 uppercase tracking-wider">Patient Details</div>
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-y-4 gap-x-4 sm:gap-x-8">
                     <div className="col-span-2">
                        <span className="text-xs text-slate-500 font-semibold block mb-0.5">Full Name</span>
                        <span className="text-lg font-bold text-slate-800 block border-b border-slate-200 pb-1">{data.patientName || "N/A"}</span>
                     </div>
                     <div>
                        <span className="text-xs text-slate-500 font-semibold block mb-0.5">Age / Sex</span>
                        <span className="text-lg font-bold text-slate-800 block border-b border-slate-200 pb-1">{data.age || "--"} / {data.gender?.charAt(0) || "-"}</span>
                     </div>
                     <div>
                        <span className="text-xs text-slate-500 font-semibold block mb-0.5">Weight</span>
                        <span className="text-lg font-bold text-slate-800 block border-b border-slate-200 pb-1">{data.weight ? `${data.weight} kg` : "--"}</span>
                     </div>
                     <div className="col-span-2 md:col-span-4 mt-2">
                         <span className="text-xs text-slate-500 font-semibold block mb-0.5">Diagnosis</span>
                         <span className="text-base font-bold text-teal-700">{data.possibleDiagnosis}</span>
                     </div>
                 </div>
             </div>
          </div>

          <div className="px-4 sm:px-8 space-y-8 min-h-[500px]">
            
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.02] z-0 overflow-hidden">
                 <Stethoscope className="w-[300px] h-[300px] sm:w-[500px] sm:h-[500px] text-teal-900" />
            </div>

            {/* MEDICATION TABLE */}
            <section className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                 <div className="bg-teal-600 text-white font-serif font-bold text-xl px-3 py-1 rounded-md shadow-md">Rx</div>
                 <h3 className="text-lg font-bold text-slate-700">Medications</h3>
              </div>
              
              <div className="rounded-xl border border-slate-200 overflow-hidden shadow-sm overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead className="bg-slate-100 text-slate-600 text-[11px] font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-4 w-12 text-center border-r border-slate-200">No.</th>
                      <th className="p-4 border-r border-slate-200">Medicine & Composition</th>
                      <th className="p-4 border-r border-slate-200">Dosage</th>
                      <th className="p-4 text-center w-24">Duration</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm">
                    {data.medicines.map((med, idx) => (
                      <tr key={idx} className={`
                        break-inside-avoid
                        ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'} 
                        border-b border-slate-100 last:border-none
                      `}>
                        <td className="p-4 text-center text-slate-400 font-bold border-r border-slate-100">{idx + 1}</td>
                        <td className="p-4 align-top border-r border-slate-100">
                          <div className="font-bold text-slate-800 text-base">{med.name}</div>
                          <div className="flex flex-wrap gap-2 mt-1.5">
                              <span className="text-[10px] uppercase font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                                  {med.category}
                              </span>
                              {med.isPrescriptionRequired && (
                                  <span className="text-[10px] uppercase font-bold text-white bg-red-500 px-1.5 py-0.5 rounded shadow-sm">
                                      Rx Required
                                  </span>
                              )}
                          </div>
                          {med.alternatives && med.alternatives.length > 0 && (
                              <div className="mt-2 text-[11px] text-slate-500 flex items-start gap-1">
                                  <span className="font-semibold text-teal-600">Alt:</span> 
                                  <span className="italic">{med.alternatives.join(", ")}</span>
                              </div>
                          )}
                        </td>
                        <td className="p-4 align-top border-r border-slate-100">
                          <div className="font-bold text-slate-800">{med.dosage}</div>
                          <div className="text-xs text-teal-700 font-medium mt-1">{med.instruction}</div>
                        </td>
                        <td className="p-4 align-top text-center font-medium text-slate-500">
                           --
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Advice Columns - Stack on mobile */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 relative z-10 break-inside-avoid">
              
              {/* Diet */}
              <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                   <div className="bg-teal-100 p-1.5 rounded-full">
                     <Utensils className="w-4 h-4 text-teal-700" />
                   </div>
                   <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wide">Diet & Lifestyle</h3>
                </div>
                <ul className="space-y-2.5">
                  {data.lifestyleDietAdvice.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-slate-600 text-sm leading-relaxed">
                      <div className="mt-1.5 w-1.5 h-1.5 bg-teal-400 rounded-full flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </section>

               {/* Clinical Advice */}
               <section className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
                   <div className="bg-blue-100 p-1.5 rounded-full">
                     <HeartPulse className="w-4 h-4 text-blue-700" />
                   </div>
                   <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wide">Doctor's Advice</h3>
                </div>
                <ul className="space-y-2.5">
                  {data.homeCareInstructions.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-slate-600 text-sm leading-relaxed">
                      <div className="mt-1.5 w-1.5 h-1.5 bg-blue-400 rounded-full flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </section>
            </div>
            
            {/* Warning Box */}
            {data.visitDoctorFlags.length > 0 && (
                <section className="mt-4 bg-red-50 border border-red-100 rounded-xl p-5 relative z-10 break-inside-avoid">
                    <h4 className="text-red-700 font-bold text-xs uppercase mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" /> Emergency Signs (Visit Hospital If)
                    </h4>
                    <div className="flex flex-wrap gap-x-6 gap-y-2">
                        {data.visitDoctorFlags.map((flag, idx) => (
                            <span key={idx} className="text-sm text-red-900/80 font-medium flex items-center gap-1.5">
                                • {flag}
                            </span>
                        ))}
                    </div>
                </section>
            )}

          </div>

          {/* Footer / Disclaimer */}
          <div className="mt-auto relative z-10 break-inside-avoid">
             <div className="px-6 sm:px-8 pb-4 pt-8">
                 <div className="flex flex-col sm:flex-row justify-between items-center sm:items-end border-t border-slate-200 pt-4 gap-6 sm:gap-0">
                     <div className="w-full sm:max-w-[65%] text-center sm:text-left">
                         <p className="text-[10px] text-slate-400 font-sans leading-relaxed text-justify">
                            <span className="font-bold text-slate-500">DISCLAIMER:</span> {data.disclaimer} This document is AI-generated for educational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician.
                         </p>
                     </div>
                     <div className="text-center pl-0 sm:pl-4">
                         <div className="font-script text-3xl text-teal-800 mb-1" style={{fontFamily: 'cursive'}}>Dr. Rohit Patel</div>
                         <div className="text-[10px] font-bold text-slate-500 border-t border-slate-300 pt-1 uppercase tracking-widest">Authorized Signature</div>
                     </div>
                 </div>
             </div>
             
             {/* Bottom Decorative Bar */}
             <div className="h-6 bg-teal-900 w-full flex items-center justify-between px-8">
                 <span className="text-[10px] text-teal-400/80 tracking-widest uppercase">Dr. Rohit Patel Clinic</span>
                 <span className="text-[10px] text-teal-400/80 tracking-widest">www.drohitpatel.ai</span>
             </div>
          </div>

          {/* Feedback Section - HIDDEN IN PDF AND SHARED VIEW */}
          {!isSharedView && (
            <section className="bg-gray-50 border-t border-gray-200 p-6 print:hidden" data-html2canvas-ignore="true">
               <div className="max-w-md mx-auto">
                  {feedbackSubmitted ? (
                      <div className="bg-green-50 p-3 rounded border border-green-100 flex items-center justify-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-green-800 text-sm font-medium">Thank you for your feedback!</span>
                      </div>
                  ) : (
                      <div className="flex flex-col items-center gap-3">
                          <span className="text-sm font-medium text-gray-600">Rate this result</span>
                          <div className="flex gap-1">
                               {[1, 2, 3, 4, 5].map((star) => (
                                  <button key={star} onClick={() => setFeedback(prev => ({ ...prev, rating: star }))} className={`transition-all hover:scale-110 ${star <= feedback.rating ? 'text-yellow-400' : 'text-gray-300'}`}>
                                      <Star className="w-6 h-6 fill-current" />
                                  </button>
                              ))}
                          </div>
                          {feedback.rating > 0 && (
                              <div className="flex w-full gap-2 animate-fade-in-up">
                                  <input 
                                      type="text" 
                                      value={feedback.comment}
                                      onChange={(e) => setFeedback(prev => ({ ...prev, comment: e.target.value }))}
                                      placeholder="Add a comment..."
                                      className="flex-1 text-sm border border-gray-300 rounded px-3 py-1.5 focus:border-teal-500 outline-none"
                                  />
                                  <button onClick={handleFeedbackSubmit} className="text-xs bg-teal-600 text-white px-3 py-1.5 rounded hover:bg-teal-700">
                                      Submit
                                  </button>
                              </div>
                          )}
                      </div>
                  )}
               </div>
            </section>
          )}

        </div>
      </div>

      {/* Action Buttons - HIDDEN IN PDF */}
      <div className={`w-full max-w-3xl mt-6 flex flex-col sm:flex-row ${isSharedView ? 'justify-center' : 'justify-between'} items-center gap-4 px-4 sm:px-0 print:hidden mb-8`} data-html2canvas-ignore="true">
        
        {/* Share Button Group */}
        <div className="relative w-full sm:w-auto">
             {!showShareMenu ? (
                <button 
                    onClick={() => setShowShareMenu(true)}
                    disabled={isDownloading}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-white text-gray-700 border border-gray-300 rounded-xl shadow-sm hover:bg-gray-50 transition-colors font-semibold"
                >
                    {isDownloading ? (
                        <>
                           <span className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></span>
                           Generating PDF...
                        </>
                    ) : (
                        <>
                           <Share2 className="w-4 h-4" /> Share / Download
                        </>
                    )}
                </button>
             ) : (
                <div className="flex items-center gap-2 animate-fade-in-up flex-wrap bg-white p-2 rounded-xl shadow-xl border border-gray-100">
                    <button 
                        onClick={() => handleShare('whatsapp')}
                        className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-[#25D366] text-white rounded-lg hover:opacity-90 text-sm font-semibold whitespace-nowrap"
                    >
                        <MessageCircle className="w-4 h-4" /> WhatsApp
                    </button>
                    <button 
                        onClick={() => handleShare('email')}
                        className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:opacity-90 text-sm font-semibold whitespace-nowrap"
                    >
                        <Mail className="w-4 h-4" /> Email
                    </button>
                    <button 
                        onClick={handleDownloadPdf}
                        className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-gray-800 text-white rounded-lg hover:opacity-90 text-sm font-semibold whitespace-nowrap"
                    >
                        <Download className="w-4 h-4" /> PDF
                    </button>
                    <button 
                        onClick={() => handleShare('copy-link')}
                        className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-purple-600 text-white rounded-lg hover:opacity-90 text-sm font-semibold whitespace-nowrap"
                    >
                        <Link className="w-4 h-4" /> Link
                    </button>
                    <button 
                        onClick={() => setShowShareMenu(false)}
                        className="px-3 py-2 text-xs text-gray-400 hover:text-gray-600"
                    >
                        <XIcon />
                    </button>
                </div>
             )}
        </div>

        {!isSharedView && (
           isHistoryView ? (
             <button 
               onClick={onReset}
               className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-gray-600 text-white rounded-xl shadow hover:bg-gray-700 transition-all font-semibold"
             >
               Back to Assistant
             </button>
           ) : (
             <button 
               onClick={onReset}
               className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 bg-teal-600 text-white rounded-xl shadow-lg shadow-teal-200 hover:bg-teal-700 transition-all font-semibold hover:scale-[1.02]"
             >
               <RefreshCw className="w-4 h-4" /> Start New Consultation
             </button>
           )
        )}
      </div>
    </div>
  );
};

const XIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
)

export default PrescriptionCard;
