
import React from 'react';
import { Stethoscope, History } from 'lucide-react';

interface HeaderProps {
  onHistoryClick?: () => void;
  showHistoryBtn?: boolean;
}

const Header: React.FC<HeaderProps> = ({ 
    onHistoryClick, 
    showHistoryBtn = true, 
}) => {
  return (
    <header className="bg-gradient-to-r from-teal-600 to-teal-800 text-white p-6 shadow-md print:hidden">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.location.href = '/'}>
          <div className="bg-white p-2 rounded-full shadow-sm">
            <Stethoscope className="w-8 h-8 text-teal-700" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Dr. Rohit Patel</h1>
            <p className="text-teal-100 text-sm font-medium">AI Health Assistant</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3 sm:gap-4">
            {showHistoryBtn && (
                <button 
                  onClick={onHistoryClick}
                  className="flex items-center gap-2 text-teal-100 hover:text-white transition-colors font-medium text-sm bg-teal-700/50 px-4 py-2 rounded-full hover:bg-teal-700 border border-teal-600/50"
                  title="View Records"
                >
                    <History className="w-4 h-4" />
                    <span className="hidden sm:inline">Records</span>
                </button>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;
