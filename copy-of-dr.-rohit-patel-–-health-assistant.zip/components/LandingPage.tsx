
import React from 'react';
import { FileText, Stethoscope, ShieldCheck } from 'lucide-react';

interface LandingPageProps {
  onDoctorAccess: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onDoctorAccess }) => {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center p-4 text-center animate-fade-in-up">
       <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full border border-teal-100 relative overflow-hidden">
           {/* Decorative Background */}
           <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-teal-500 to-teal-700"></div>
           
           <div className="bg-teal-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 border border-teal-100">
               <FileText className="w-10 h-10 text-teal-700" />
           </div>
           
           <h1 className="text-2xl font-serif font-bold text-gray-800 mb-2">Patient Portal</h1>
           <p className="text-teal-600 font-medium text-sm uppercase tracking-widest mb-6">Dr. Rohit Patel Clinic</p>
           
           <p className="text-gray-500 mb-8 leading-relaxed text-sm">
               Welcome to the digital health assistant.
               <br/><br/>
               To view your personalized health guidelines, please use the <strong>secure link</strong> sent to you via WhatsApp or Email.
           </p>

           <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 text-xs text-blue-800 mb-8 text-left flex gap-3">
               <ShieldCheck className="w-5 h-5 flex-shrink-0 text-blue-600" />
               <div>
                   <strong>Secure Access:</strong> Your prescription is protected. Please check your messages for a link starting with <em>?rx=...</em>
               </div>
           </div>

           <div className="border-t border-gray-100 pt-6 mt-2">
               <p className="text-[10px] text-gray-400 mb-3 uppercase tracking-wider font-bold">For Clinic Staff</p>
               <button 
                 onClick={onDoctorAccess}
                 className="flex items-center justify-center gap-2 w-full py-3.5 bg-gray-800 hover:bg-gray-900 text-white rounded-xl transition-all text-sm font-semibold shadow-lg hover:shadow-xl hover:scale-[1.02]"
               >
                   <Stethoscope className="w-4 h-4" />
                   Open Doctor Console
               </button>
           </div>
       </div>
       
       <p className="mt-8 text-xs text-gray-400">© {new Date().getFullYear()} Dr. Rohit Patel AI Health Assistant</p>
    </div>
  );
}

export default LandingPage;
