
import React, { useMemo } from 'react';
import { PrescriptionData } from '../types';
import { Calendar, User, ChevronRight, FileText, Database } from 'lucide-react';

interface HistoryViewProps {
  history: PrescriptionData[];
  onSelect: (item: PrescriptionData) => void;
  onBack: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ history, onSelect, onBack }) => {
  
  // Calculate analytics for the calendar
  const calendarData = useMemo(() => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    
    // Create an array of days [1..30/31]
    const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
    
    // Group history by date (Day number) for the current month
    const checkIns = history.reduce((acc, item) => {
        if (!item.timestamp) return acc;
        const date = new Date(item.timestamp);
        if (date.getMonth() === currentMonth && date.getFullYear() === currentYear) {
            const day = date.getDate();
            acc[day] = (acc[day] || 0) + 1;
        }
        return acc;
    }, {} as Record<number, number>);

    return { days, checkIns, currentMonthName: today.toLocaleString('default', { month: 'long' }), currentYear };
  }, [history]);

  return (
    <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100 animate-fade-in-up">
       <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
         <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-teal-600" />
            <h2 className="text-lg font-semibold text-gray-800">Consultation History</h2>
         </div>
         <button onClick={onBack} className="text-sm text-teal-600 hover:underline">
            Back to New
         </button>
       </div>

       {/* Calendar Summary Section */}
       <div className="p-6 border-b border-gray-100 bg-teal-50/30">
          <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wide">Patient Check-ins: {calendarData.currentMonthName} {calendarData.currentYear}</h3>
              <span className="text-xs text-gray-500">Total: {history.length}</span>
          </div>
          <div className="grid grid-cols-7 gap-2">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
                  <div key={i} className="text-center text-xs font-bold text-gray-400">{d}</div>
              ))}
              {/* Note: This simplistic grid starts Day 1 at col 1. For a real calendar, we'd add offset based on day of week. */}
              {calendarData.days.map(day => {
                  const count = calendarData.checkIns[day] || 0;
                  return (
                      <div key={day} className="flex flex-col items-center">
                          <div 
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all
                                ${count > 0 
                                    ? 'bg-teal-600 text-white shadow-md scale-105' 
                                    : 'bg-white text-gray-400 border border-gray-100'}`}
                            title={count > 0 ? `${count} check-ins` : 'No check-ins'}
                          >
                              {day}
                          </div>
                          {count > 0 && <span className="text-[9px] text-teal-700 font-bold mt-0.5">{count}</span>}
                      </div>
                  );
              })}
          </div>
       </div>

       <div className="p-0">
          {history.length === 0 ? (
            <div className="p-10 text-center text-gray-500">
                <p>No history found.</p>
                <p className="text-sm mt-1">Generate a prescription to see it here.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
                {history.map((item) => (
                    <div 
                        key={item.id} 
                        onClick={() => onSelect(item)}
                        className="p-4 hover:bg-gray-50 cursor-pointer flex items-center justify-between transition-colors group"
                    >
                        <div className="space-y-1">
                            <div className="flex items-center gap-2 text-gray-900 font-bold">
                                {item.patientName || "Unknown Patient"}
                            </div>
                            <div className="text-sm text-teal-700 font-medium">
                                {item.possibleDiagnosis}
                            </div>
                            <div className="flex items-center gap-3 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                    <Calendar className="w-3 h-3" />
                                    {item.timestamp ? new Date(item.timestamp).toLocaleDateString() : 'N/A'}
                                </span>
                                <span className="flex items-center gap-1">
                                    <User className="w-3 h-3" />
                                    Dr. Rohit Patel
                                </span>
                            </div>
                        </div>
                        <div className="text-gray-400 group-hover:text-teal-600 transition-colors">
                            <ChevronRight className="w-5 h-5" />
                        </div>
                    </div>
                ))}
            </div>
          )}
       </div>
       
       <div className="p-4 bg-gray-50 text-center border-t border-gray-100 flex items-center justify-center gap-2 text-xs text-gray-400">
          <Database className="w-3 h-3" />
          <span>All records are stored locally on this device.</span>
       </div>
    </div>
  );
};

export default HistoryView;
