
import React, { useState } from 'react';
import { Lock, ShieldCheck, ChevronRight } from 'lucide-react';

interface AccessControlProps {
  onSuccess: () => void;
}

const AccessControl: React.FC<AccessControlProps> = ({ onSuccess }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Hardcoded PIN for owner access
    if (pin === '1234') {
      onSuccess();
    } else {
      setError('Access Denied: Incorrect PIN');
      setPin('');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up border border-teal-100">
        <div className="bg-teal-800 p-8 text-center relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-full bg-teal-600 opacity-20 transform rotate-45 scale-150"></div>
           <div className="relative z-10">
               <div className="bg-white/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm border border-white/20">
                 <Lock className="w-8 h-8 text-white" />
               </div>
               <h2 className="text-xl font-bold text-white font-serif tracking-wide">Dr. Rohit Patel</h2>
               <p className="text-teal-200 text-xs font-medium uppercase tracking-widest mt-2">Practitioner Console</p>
           </div>
        </div>

        <form onSubmit={handleLogin} className="p-8 space-y-6">
            <div className="text-center">
                <p className="text-gray-500 text-sm">Please enter your security PIN to access the prescription generation tools.</p>
            </div>

            <div className="space-y-4">
                <div className="relative">
                    <input 
                        type="password" 
                        inputMode="numeric"
                        placeholder="Enter PIN"
                        value={pin}
                        onChange={(e) => { setPin(e.target.value); setError(''); }}
                        className="w-full text-center text-2xl font-bold tracking-[0.5em] py-3 border-b-2 border-gray-200 focus:border-teal-600 outline-none transition-colors text-gray-800 placeholder:tracking-normal placeholder:text-base placeholder:font-normal"
                        autoFocus
                    />
                </div>
                
                {error && (
                    <div className="text-center text-xs text-red-500 font-bold bg-red-50 py-2 rounded">
                        {error}
                    </div>
                )}
            </div>

            <button 
                type="submit" 
                className="w-full bg-teal-700 hover:bg-teal-800 text-white font-bold py-3.5 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 group"
            >
                <ShieldCheck className="w-4 h-4" /> 
                Access System
                <ChevronRight className="w-4 h-4 opacity-50 group-hover:translate-x-1 transition-transform" />
            </button>
        </form>
        
        <div className="bg-gray-50 py-3 text-center border-t border-gray-100">
             <p className="text-[10px] text-gray-400">Restricted Area • Authorized Personnel Only</p>
        </div>
      </div>
    </div>
  );
};

export default AccessControl;
